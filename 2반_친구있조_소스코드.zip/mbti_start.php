<?php
    require_once('db.php');
    $name = $_GET['name'];
    $query = 'select * from result where name="kastor";';
    $result = connect($query);
    $row = mysqli_fetch_array($result);
    $mbti = $row['mbti'];
    echo $mbti;
?>