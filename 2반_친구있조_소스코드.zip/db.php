<?php 
    function connect($query){
        $db = mysqli_connect('localhost','syclones','kastor#1219','syclones'); //설정해야함
        #$db = mysqli_connect('localhost','root','1234','sunrin');
        // $query= "select * from question where idx="."$idx;";
        $result = mysqli_query($db, $query);
        
        return $result;
    }
    
?>