<?php
    require_once('db.php');
    $name = $_GET['name'];
    $query = 'select * from result where name="'.$name.'";';
    $result = connect($query);
    $row = mysqli_fetch_array($result);
    $mbti = $row['mbti'];
?>
<html>
    <head>
        <meta charset="utf-8" />
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
            <meta name="description" content="" />
            <meta name="author" content="" />
            <title>MBTI TEST RESULT</title>
            <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
            <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
            <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
            <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
            <link href="css/styles.css" rel="stylesheet" />
            <link href="css/checkbox1.css" rel="stylesheet" />
            <style>
                .center{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                }
                .black {
                    --bs-bg-opacity: 1;
                     background-color: rgba(var(255,255,255), var(--bs-bg-opacity)) !important;
                }
            </style>
        </head>
    <body bgcolor="#198754">
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="./main.html">MBTI TEST</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
        </nav>
        <header class="masthead bg-primary text-white text-center">
            <div class="divider-custom divider-light">
                <div class="divider-custom-line"></div>
                <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                <div class="divider-custom-line"></div>
            </div>
            <br>
            <div class="container d-flex align-items-center flex-column">
                <h1 class="masthead-heading text-uppercase mb-0">결과 확인하기</h1>
                <div class="text-center mt-4">
                </div>
                
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
            </div>
            <section class="page-section portfolio" id="portfolio">
                <div class="container">
            <div class="col-md-6 col-lg-4 mb-5">
                <div class="portfolio-item mx-auto" data-bs-toggle="modal" data-bs-target="#portfolioModal2">
                    <div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100">
                        <div class="portfolio-item-caption-content text-center text-white"><i class="fas fa-plus fa-3x"></i></div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            </section>
            <section class="bg-primary text-white mb-0" id="about">
                <div class="row">
                    <?php
                        if ($mbti == 'ESFP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/cafemoca.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ESFP이며, 추천 음료는 카페모카입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ESTJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/americano.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ESTJ이며, 추천 음료는 아메리카노입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ESTP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/cafelatte.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ESTP이며, 추천 음료는 카페라떼입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'INTP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/caramelmaki.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 INTP이며, 추천 음료는 카라멜 마끼야또입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'INFP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/camomile.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 INFP이며, 추천 음료는 캐모마일 릴렉서입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ISTP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/capuchino.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ISTP이며, 추천 음료는 카푸치노입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'INFJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/topinut.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 INFJ이며, 추천 음료는 토피넛 라떼입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ENTJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/dolcha.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ENTJ이며, 추천 음료는 돌차라떼입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ENFJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/javachip.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ENFJ이며, 추천 음료는 자바칩 프라푸치노입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ISFP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/vanila.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ISFP이며, 추천 음료는 바닐라 라떼입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'INTJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/coldbrue.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 INTJ이며, 추천 음료는 콜드브루입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ESFJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/goldenwish.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ESFJ이며, 추천 음료는 골든 위시 라떼입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ISTJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/nitrovanila.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ISTJ이며, 추천 음료는 나이트로 바닐라입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                        else if($mbti == 'ENTP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/jamong.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ENTP이며, 추천 음료는 자몽 허니 블랙티입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                         else if($mbti == 'ENFP'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/pichalemon.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ENFP이며, 추천 음료는 피치 레몬 블렌디드입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }
                         else if($mbti == 'ISFJ'){
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><img class="img-fluid" src="assets/img/portfolio/signaturechocolate.png" alt="..." /></div>';
                            echo '<div class="portfolio-item-caption d-flex align-items-center justify-content-center h-100 w-100"><p class="lead">당신의 MBTI는 ISFJ이며, 추천 음료는 시그니처 초콜릿입니다. <br>자세한 설명은 메인 화면 내 해당 음료를 눌러주세요!</p></div>';
                        }

                    ?>
                </div class="row justify-content-center text-center center">
            </div>
            </section>
        
    </body>

</html>