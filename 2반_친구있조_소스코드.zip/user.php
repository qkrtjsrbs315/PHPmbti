<?php 
    require_once('db.php');
    $idx =$_GET['idx'];
    $query = 'select * from question where idx='.$idx.';';
    $result = connect($query);
    $row = mysqli_fetch_array($result);
    $all_table_num = 'select * from question;';
    #$num =3;
    $num =  mysqli_num_rows(connect($all_table_num)); //전체 행을 가져옴
    $result = connect($query);
    $row = mysqli_fetch_array($result);
    $left = $row['ans1'];
    $right = $row['ans2'];
    $left_first_score = (int)$row['left_first_score']; //e 이상 x
    $left_second_score = (int)$row['left_second_score']; //s 
    $left_third_score = (int)$row['left_third_score']; // t
    $left_fourth_score = (int)$row['left_fourth_score']; // j
    $right_first_score = (int)$row['right_first_score']; //i
    $right_second_score = (int)$row['right_second_score']; //n
    $right_third_score = (int)$row['right_third_score']; //f 
    $right_fourth_score = (int)$row['right_fourth_score']; //p
    $name = $_COOKIE['name'];
    #$insert_query = 'update user set first_score = '.$right_first_score.' where name="'.$name.'";';
    $mbti = '';
    $id = (int)$idx+1;

      if ($idx == $num){
       //연산
        if ($_POST["mybutton"] == $left){
            $insert_query  = 'insert into user(name, first_score, second_score, third_score, fourth_score) values';     //완벽함
            $insert_query = $insert_query."('$name',$left_first_score,$left_second_score,$left_third_score,$left_fourth_score);";
            connect($insert_query);
        }
        else if ($_POST['mybutton'] == $right){
            $insert_query  = 'insert into user(name, first_score, second_score, third_score, fourth_score) values';     //완벽함
            $insert_query = $insert_query."('$name',$right_first_score,$right_second_score,$right_third_score,$right_fourth_score);";
            connect($insert_query);
        }
       $first_query = 'select sum(first_score) as first from user where name ="'.$name.'"; ';
       $second_query = 'select sum(second_score) as second from user where name ="'.$name.'"; ';
       $third_query =  'select sum(third_score)  as third from user where name ="'.$name.'"; ';
       $fourth_query = 'select sum(fourth_score) as fourth from user where name ="'.$name.'"; ';
       $row1 = connect($first_query);
       $row2 = connect($second_query);
       $row3 = connect($third_query);
       $row4 = connect($fourth_query);
      
       
       $first = mysqli_fetch_array($row1); //작동함
       $num1 = $first['first'];
       echo $num1;
       $second = mysqli_fetch_array($row2);
       $num2 = $second['second'];
        $third = mysqli_fetch_array($row3);
       $num3 = $third['third'];
       $fourth = mysqli_fetch_array($row4);
       $num4 = $fourth['fourth'];

       if ($num1 / 3 > 5) {$mbti=$mbti.'E';}
       else {$mbti=$mbti.'I';}
       if ($num2 / 3 > 5) {$mbti=$mbti.'S';}
       else {$mbti=$mbti.'N';}
       if ($num3 / 3 > 5) {$mbti=$mbti.'T';}
       else {$mbti=$mbti.'F';}
       if ($num4 / 3 > 5) {$mbti=$mbti.'J';}
       else {$mbti=$mbti.'P';}
       
       $mbti_query = "insert into result(mbti,name) values";
       $mbti_query = $mbti_query."('$mbti','$name');";
       connect($mbti_query);
       echo "<script>location.href ='./result.php?name=".$name."'</script>";
   }
   else if ($idx < $num){
    if ($_POST["mybutton"] == $left){
         $insert_query  = 'insert into user(name, first_score, second_score, third_score, fourth_score) values';     //완벽함
        $insert_query = $insert_query."('$name',$left_first_score,$left_second_score,$left_third_score,$left_fourth_score);";
        connect($insert_query);
       echo "<script>location.href ='./question.php?idx=".$id."'</script>";
    }
    else if ($_POST['mybutton'] == $right){
        $insert_query  = 'insert into user(name, first_score, second_score, third_score, fourth_score) values';     //완벽함
        $insert_query = $insert_query."('$name',$right_first_score,$right_second_score,$right_third_score,$right_fourth_score);";
        connect($insert_query);
        echo "<script>location.href ='./question.php?idx=".$id."'</script>";
    }
   }
?>
