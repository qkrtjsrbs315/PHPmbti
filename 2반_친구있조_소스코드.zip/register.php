<?php
    require_once('db.php');
    $name = $_GET['user_name'];
    $query = 'selct * from user where name="'.$name.'";';
    $result = connect($query);

    if (!$result){
        $query = "insert into user(name) values('".$name."');";
        $result = connect($query);
        echo '<script>alert("회원가입이 완료되었습니다");location.href = "http://syclones.dothome.co.kr/question.php?idx=1";</script>';
        setcookie('name', $name,time()+60*5);
    }
    else 
    {
        echo '<script>alert("다시 입력해주세요.");location.href = "http://syclones.dothome.co.kr/sendname.php";</script>';
    }

?>
